/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 电子签名展示页
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    
    var Page = View.extend(_.extend({
        events: {
            'tap #js-back': 'back'
        },
        back: function(e) {
            e = e || window.event;
            e.stopPropagation();
            window.location.href = 'iloan_api_esign.html?key='+C.Utils.getParameter('key');
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});