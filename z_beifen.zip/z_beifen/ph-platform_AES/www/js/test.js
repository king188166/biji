/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 电子签名展示页
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    
    var Page = View.extend(_.extend({
        initialize: function() {
            // var JSEncrypt = require('../libs/jsencrypt');
            // console.log(JSEncrypt);
            // var privateKey = 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCWeoOIDPm3HlxhSq4azD7IPCusy7mX8ZOmNsLeRV4M+If6LW8i/ALgD/UzlhDzLRk7Vy2nx1NvXbredhX1WTs4GrBEFvx61PwuNPQdcbs+8OWSexzsMHG1GKueLEhF5tatEWPSVTzasdLdc4LO1E/r8B3fqcZRmTYMecRBd1Wz5F3dr10732qXCBpaDEEfGVKTYGs2bpEUd/drqaminx1gjSwZ17iltw38wIJOzMn0fPZXbAMFzd+V+98dA9UT+qPL1gPOzlQbbhSpmRibF/ObVqAxS276Oqtoicn1nRU0zr4M/0Jx7arrC++Sc60D+WxLIfvMIlonGdCXlUyz2j5PAgMBAAECggEAbT2pqSYKTvbah8LoXAn0dfbAmiQXqwe0cZEFrMjc+zuds3AyY0piZ/kNwBJsYa1WyO6D9W5N0uZPl9pQHJpX1GYDmpq5Vg6yuHS2131OOuY1Mz7vA0Qz+A1d4WkyWpS3OlMKjZJVqEo504xc5PvavWTGuy2MDIbWZv4rDH+ulvXQeTpjAUykzGSZjzcMEcdRzANN8OicelXEZTu3g1X0z9X0fJRqfXufDDo0XUR2x/fHZMT/qwabb58IMqk0htJ7tO4lQXGcq4pAIdP+SQsDeMxw+SLadKyVBaWufvjPAwUNvtekRAUY92tknDdN6tb5hLjadYE12BmpHr/vxIBpSQKBgQDFAyqJVbC46F4avvEjQ2RS+GCnLeA/062KFDfC918yqNXir/GPynXpxpIkl4rcsxW3GkCgkvp+7gVmVpEq1R/r7WPf/cTn4YtkQDyXH5ko96NaA6O5gBh32WjlBl0bUjJhq+l1CWiTsI+EP5WKkSBHwuteJGGn0aX3YCddzKPfgwKBgQDDiJId70GYm5ewIhhObQMaM2ME83c+HpK+QH7TtPb8QS9FOX0s5eAeRwmjpv4QggHJH4T4wnsZNZIkrPqIilSCOdrXy0vXlmGMJneY5jRpIWfm3FCy7z103/LvvxGrYYa1wQscONKtBTm0AOy5+EUYQ/6CgIjBprA66EBZn2UARQKBgQCiajXK+kWyan4J9pe8xnYSoIityfgxJkTOrFQ7+ssUbHPHadzu+a2zh+w7FmN4BntEc/QLbJ/tvDPfZkZO1Vx3l0DbC84ki5/qibppq7cMOvsD3jQ/XQbO5wC+rjxbpau7MYpI3fTErK3kDLcvgOznvB1lgwCu5Pq5sR9DCM2gGQKBgGaYeyqPxlhfk3jMevpzgoQ14EfRw4hpnE+NIb7NniZ/wWDOKFrthun8FhezYG2i+XLhQfEQgmyYykTKKm6IPo1R8/z0Y6gL9MUHzgsBBxD+gTkF8qXgl9uCQkL/ezL0ai1lzAGT4x77teo37f4qQX7Y9mrdLGSHpMJT6Kfd1a4NAoGAERAKLAcIcE9sMzGRvxGwyMA7EL/Chk3HohnBKwj4YkRPvswVAIfcVCaEH/hPqMKyLk6GPrhZOUr47lKP3l3SZnG/37KOiE6TbbF2Le0CGD45KbVEfmsbT/qzrm5d7keVtVZbw6QpexM4RqCsmCEwqu4HOTTom8AawkiJVcn5dno=';
            // var RSADECRYPT = new JSEncrypt();
            // console.log(RSADECRYPT);
            // RSADECRYPT.setPrivateKey(privateKey);
            // var rsaDecrypt = function (text) {
            //     return RSADECRYPT.decrypt(text);
            // };
            // var aa = rsaDecrypt('eS/K8CzayZw3z1G/e1aL4sggYL6R3AuwyiI6AEjJXU06R2iupJsDfFaMFCxK/kWjD5fWe1g7CJ4xtHoN7UXXpWCQ+1tChIpb3zWzDVY7uF4XxWntNFBqqhW1GfdFl6uey1+1Nes5xVEVbnE7q3FWaHq0a5GXSe+Fu4dFJKVIEdTmM7QO/fmQ496JwA1MHmvIgtwFQdi7xWzA1mKTL5D16FqL+vvs1pGZ0/fRWJv8RqX6g6iZ8E95YRML7DpYKH5Dhuxgucb/lLnDXSymjzre0pAR8aix2gLR88Ock9at8MM4JaG3gN2E/0KGxwjSD+WJH/L6FYLkyOCOUAJNPiJo6Q==');
            // console.log(aa);

            //var  a = '我们成功了';
            //var b = C.Utils.AESEncrypt(a, 'Encrypt');
           // console.log(b);
            // var c = C.Utils.AESDecrypt('{"fundingModel":"U","cgiBankName":"重庆银行","eType":"UP","signElectSw":"Y","loanCompanyCode":"L","isCredit":"1","successLink":"iloan_api_contract.html","failLink":"iloan_api_data_transfer_contract.html"}', 'Encrypt'); 
            // alert(c);
            // console.log(c);
            var d = C.Utils.AESDecrypt('EmN+RI/APcU7l0nHznUBO79lBMGZ2iOpBPtGeYlCKRWG+71paJ0qdbLHDxQbiOl/P82lxQCYbsZYMpkwD2YU5FxZcBr1RNeAC4i74UHcFMZWIg2kJSNbHoDiLmQFQnObaaqHDHCU6d/ih8dIplbq11ZX83fFVe62GcOTEXM1HGDM5/d+ZMGD7g1c7G+wf8juTdhKs8B2SUBxz6EBtskwNg==', 'Decrypt');
            console.log(d);
        }
        
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});

