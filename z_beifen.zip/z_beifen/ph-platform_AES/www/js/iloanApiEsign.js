/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 电子签名展示页
 */
define(['zepto', 'C', 'view', 'js/dosign'], function ($, C, View, dosign) {
    'use strict';
    C.FastClick.attach(document.body);
    var Page = View.extend(_.extend({
        events: {
            'tap #qian-input': 'esign',
            'tap #js-contract-synthetical': 'toSyntheticalAuth',
            'tap #js-contract-personal': 'toPersonalAuth',
            'tap #js-contract-synthetical-cgi': 'toSyntheticalCgiAuth',
            'tap #bank_contract_title': 'toBankAuth'
        },
        initialize: function() {
            this.barCode = 'iloan' + Math.round(Math.random() * 1000) + new Date().getTime();
            this.config = {
                businessId: this.barCode,                   // 集成信手书业务的唯一标识
                template_serial: '1#4000',                  // 用于生成PDF的模板ID
                channel: '10010',                           // 渠道号，由信手书提供，请咨询项目经理
                sign_keyword: '授权人'                       // 签名关键词
            },
            this.paramsObj = this.getQueryParams();
            this.render(this.paramsObj);
        },
        getQueryParams: function() {
            this.forwardParams = C.Utils.getParameter('key') || 'EmN+RI/APcU7l0nHznUBO79lBMGZ2iOpBPtGeYlCKRWG+71paJ0qdbLHDxQbiOl/P82lxQCYbsZYMpkwD2YU5FxZcBr1RNeAC4i74UHcFMZWIg2kJSNbHoDiLmQFQnObaaqHDHCU6d/ih8dIplbq11ZX83fFVe62GcOTEXM1HGDM5/d+ZMGD7g1c7G+wf8juTdhKs8B2SUBxz6EBtskwNg==';
            var keys = JSON.parse(C.Utils.AESDecrypt(this.forwardParams, 'Decrypt'));
            var params = {
                // 上传电子签名接口所需入参
                accountId: keys.accountId,
                OS: keys.OS,
                token: keys.token,
                // 授权书的展示相关字段
                eType: keys.eType,
                fundingModel: keys.fundingModel,
                signElectSw: keys.signElectSw, // 电子签名开关
                cgiBankName: keys.cgiBankName,
                loanCompanyCode: keys.loanCompanyCode,
                isCredit: keys.isCredit,

                ratio: keys.retio || '',
                // 银行变更接口所需字段
                newBank: keys.newBank || '',
                bankCode: keys.bankCode || '',
                applyNo: keys.applyNo || '',
                payApplyNo: keys.payApplyNo || '',
                // 成功失败的返回页面
                successLink: keys.successLink,
                failLink: keys.failLink
            };
            // 银行变更场景时，不返回signElectSw字段
            if(params.eType === 'UP'){
                params.signElectSw = 'Y';
            }
            this.signElectSw = params.signElectSw;
            return params;
        },
        // 渲染电子签名页面
        render: function(data) {
            // 显示日期
            var date = new Date();
            var month = parseInt(date.getMonth())+1;
            data.today = date.getFullYear()+'-'+month+'-'+date.getDate();
            // 渲染页面
            $('#contract_preview').html(_.template($('#js-contract-pre').html(), data));
            //银行变更时隐藏个人征信和综合授权书
            if(data.eType.toUpperCase() === 'UP') {
                $('.isShow').addClass('dn');
            }
            // 电子签名
            if (data.signElectSw === 'N') {
                this.successLink = data.successLink;
                $('#qian-input').html('同意并授权');
            } else {
                dosign.init(this.config);
            }
            // 综合授权页展示银行征信：U 并且需要征信；变更银行电子签名页必须征信，对应银行字段 newBank
            if (data.fundingModel && data.isCredit && data.fundingModel == 'U' && data.isCredit == '1' || !!data.newBank) {
                var bankClass = C.Constant.BANKCONTRACT[data.cgiBankName] || C.Constant.BANKCONTRACT[data.newBank];
                $('.'+bankClass).removeClass('dn');
            }
            $('#contract_preview').show();
        },
        esign: function(e){
            console.log('111');
            e = e || window.event;
            e.stopPropagation();
            if (this.signElectSw === 'Y') {
                $('.container').addClass('dn');
                $('.signature-body').removeClass('dn');
                
            } else {
                window.location.href = this.successLink;
            }
        },
        
        // 提交电子签名信息
        submitEsign: function () {
            var params = {};
            if (this.paramsObj.signElectSw === 'Y') {
                params.imgDenseStr = this.imgDenseStr;
                params.imgBytes = this.imgBytes;
            }
            params.accountId = this.paramsObj.accountId;
            params.loanCompanyCode = this.paramsObj.loanCompanyCode;
            params.platform = App.IS_IOS ? 'IOS' : 'A';
            params.businessNo = this.barCode;
            params.fundingModel = this.paramsObj.fundingModel;
            params.cgiBankName = this.paramsObj.cgiBankName;
            params.ratio = this.paramsObj.ratio; 
            params.productId = 'ILOANBT'; 
            // ocr参数可写成固定配置
            params.ocrKey = 'N';
            params.ocrNeed = 'Y';
            params.isDomesticAlgorithm = 'Y';
            // 银行变更接口所需参数
            params.bankName = this.paramsObj.newBank;
            params.bankCode = this.paramsObj.bankCode;
            params.applyNo = this.paramsObj.applyNo;
            params.payApplyNo = this.paramsObj.payApplyNo;
            console.log(params);
            $('.shadding').show();
            var self = this;
            $.ajax({
                url: C.Api('UPLOADPOSELECTRONICSIGNATURE'),
                type: 'post',
                //dataType: 'jsonp', 通过在init中设置crossDomain: 'true',解决跨域问题
                data: {
                    jsonPara: JSON.stringify(params)
                },
                success: function (res) {
                    if (res.flag == '1') {
                        console.log(self.paramsObj.successLink);
                        window.location.href = self.paramsObj.successLink;
                    } else {
                        window.location.href = self.paramsObj.failLink;
                        
                    }
                },
                complete: function () {
                    $('.shadding').hide();
                }
            });
        },
        // 处理电子签名
        cancelCb: function(){
            $('.container').removeClass('dn');
        },
        successCb: function(){
            $('.container').removeClass('dn');
            this.imgBytes = dosign.toJSON().imageData;
            // 将signData的双引号替换成#号
            this.imgDenseStr = dosign.toJSON().signData;
            this.submitEsign();
        },
        // 跳转至个人征信页
        toPersonalAuth: function(){
            window.location.href = 'iloan_api_auth_personal.html?key='+this.forwardParams;
        },
        // 跳转至综合授权书页 担保
        toSyntheticalAuth: function(){
            window.location.href = 'iloan_api_auth_synthetical.html?key='+this.forwardParams;
        },
        // 跳转至综合授权书页 联合放款
        toSyntheticalCgiAuth: function(){
            window.location.href = 'iloan_api_auth_synthetical_cgi.html?key='+this.forwardParams;
        },
        // 跳转至银行征信
        toBankAuth: function(){
            window.location.href = 'iloan_api_auth_bank.html?key='+this.forwardParams;
        }
    }));
    $(function() {
        window.esignPage = new Page({
            el: $('body')[0]
        });
    });
});