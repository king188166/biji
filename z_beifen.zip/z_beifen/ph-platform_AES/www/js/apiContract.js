/**
 * @author: ex-dushanshan001@pingan.com.cn
 * @date  : 2017-08-30
 * @describe: 合同签订(借款协议)
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';

    var Page = View.extend({
        initialize: function() {
            var keys = C.Utils.getParameter('key');
            var paramsObj = JSON.parse(C.Utils.AESDecrypt(keys));

            var params = {
                applyNo: paramsObj.applyNo,
                custName: paramsObj.custName,
                Id: paramsObj.id,
                credit: C.Utils.formatMoney(paramsObj.credit)
            };
            this.render(params);
        },
        // 初始页面渲染
        render: function(data) {
            console.log(data);
            $('#js-wrap-applyNo').html(_.template($('#js-html-applyNo').html(), data));
            $('#js-wrap-contract').html(_.template($('#js-html-contract').html(), data));
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});