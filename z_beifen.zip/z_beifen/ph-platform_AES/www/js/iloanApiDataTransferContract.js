/**
 * @author: ex-dushanshan001@pingan.com.cn
 * @date  : 2017-08-30
 * @describe: 资料代传合同
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        initialize: function() {
            var paramsObj = C.Utils.getParameter('key');
            var data = JSON.parse(C.Utils.AESDecrypt(paramsObj));
            // 渲染页面
            $('#js-applyNo').html(data.applyNo);
            $('#js-wrap-contract').html(_.template($('#js-html-contract').html(), data));
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});