/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 电子签名展示页
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    
    var Page = View.extend(_.extend({
        events: {
            'tap #js-back': 'back'
        },
        initialize: function() {
            var keys = C.Utils.getParameter('key')||'igYkxggiij37bgVXghmlg+JFQv4zdxN/TzS/xomtrvu3SiUCk1Iwayysem2Rz2SlBW6FBMuXX7tLCi29R5nfIGdBDQZSjxnN/epjtMJ/6NzhuKIBvM1JicEy0D/CXz+3Egyl9Rl92TzOcQqzbJk3A6HcMElngmO73x7m54QP6sPtZb/BFSZqjXKG+JfCo/fMvnJ8bWbZJTaZfLytKbD6mQ==';
            var params = JSON.parse(C.Utils.AESDecrypt(keys, 'Decrypt'));
            this.render(params);    
        },
        render: function(data){
            var bank = data.cgiBankName || data.newBank;
            if(bank && data.isCredit === '1'){
                var bankClass = C.Constant.BANKCONTRACT[bank];
                $('.'+bankClass).removeClass('dn');
            }
        },
        back: function() {
            window.location.href = 'iloan_api_esign.html?key='+C.Utils.getParameter('key');
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});