/**
 * @author: ex-dushanshan001@pingan.com.cn
 * @date  : 2017-08-30
 * @describe: 合同签订(借款协议)
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';
    var Page = View.extend({
        initialize: function() {
            var keys = C.Utils.getParameter('key');
            var paramsObj = JSON.parse(C.Utils.AESDecrypt(keys));
            this.params = {
                fundingModel: paramsObj.fundingModel,
                versionNo: paramsObj.versionNo,
                loanCompanycode: paramsObj.loanCompanyCode
            };
            this.PRODUCTION = {
                cgiVersion: {
                    'L': 'v3.0',
                    'H': 'v3.1',
                    'C': 'v3.2'
                },
                version: 'v1.1'
            };
            this. CONTRACTHTML = {
                cgiContract: {
                    'v2.0': 'api_contract_cgi_2.0.html',
                    'v3.0': 'api_contract_cgi_3.0.html',
                    'v3.1': 'api_contract_cgi_3.1.html',
                    'v3.2': 'api_contract_cgi_3.2.html'
                },
                contract: {
                    'v1.0': 'api_contract_1.0.html',
                    'v1.1': 'api_contract_1.1.html'
                }
            };
            this.showContract();
        },
        showContract: function(){
            // 显示协议内容
            var key = C.Utils.getParameter('key');
            var url;
            if(this.params.fundingModel.toUpperCase() === 'U' || this.params.fundingModel.toUpperCase() === 'D'){
                if(!!this.params.versionNo){ // versionNo有值
                    url = this.CONTRACTHTML.cgiContract[this.params.versionNo]+'?key='+key;
                } else {
                    url = this.CONTRACTHTML.cgiContract[this.PRODUCTION.cgiVersion[this.params.loanCompanycode]]+'?key='+key;
                }
            }else{
                if(!!this.params.versionNo){
                    url = this.CONTRACTHTML.contract[this.params.versionNo]+'?key='+key;
                } else {
                    url = this.CONTRACTHTML.contract[this.PRODUCTION.version]+'?key='+key;
                }
            }
            window.location.href = url;
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});