/**
 * @author: jinmengjie107@pingan.com.cn
 * @date  : 2015-10-22
 * @time  : 上午09:10
 *
 * @describe: H5电子签名
 */
// 'use strict';
var apiInstance;
var params;

function setAlertTitle(config) {
    'use strict';
    if(!!config) {
        params = config;
    }
    var oInput = document.getElementById('qian-input');
    var oImg = document.getElementById('img');
    oInput.addEventListener('click', function () {
        testPopupDialog(20);
    });
    oImg.addEventListener('click', function () {
        testPopupDialog(20);
    });
    testAnySign(112321321);
    testSetTemplateData();
}


//配置模板数据
function testSetTemplateData() {
    'use strict';
    var formData = "<html><head></head><body><div id=\"colArea\" class=\"pageFormContent\" style=\"width:95%;background:#f9fbf9;display:block;\"><div class=\"unit\"><label class=\"fontLabel\">keyword：</label></div><div class=\"unit\"><label class=\"fontLabel\">列名2：</label></div><div class=\"unit\"><label class=\"fontLabel\">列名3：</label></div></div></body></html>";
    var businessId = params.businessId;     //集成信手书业务的唯一标识

    var template_serial = params.template_serial;   //用于生成PDF的模板ID
    var channel = params.channel;                   //渠道号，由信手书提供，请咨询项目经理

    var res;

    //配置JSON格式签名原文
    res = apiInstance.setTemplate(TemplateType.HTML, formData, businessId, template_serial);
    if (res) {
        //alert('setTemplateData success');
        return res;
    }
    else {
        //alert('setTemplateData error');
        return res;
    }
}

//添加签名框
function testAddSignatureObj(objId) {
    var context_id = objId;
    // 授权人 签名
    var signatureConfig = new SignatureConfig(new Signer('李明', '11011111111'), new SignRule_KeyWord(params.sign_keyword, '2', 0, 1));

    var res = apiInstance.addSignatureObj(context_id, signatureConfig);
    if (res) {
        return res;
    }
    else {
        return res;
    }
}
//demo总入口
function testAnySign(channel) {

    var res;
    var callback = function (context_id, context_type, val) {
        if (context_type == CALLBACK_TYPE_START_RECORDING || context_type == CALLBACK_TYPE_STOP_RECORDING) {
            return;
        }
        if (context_type == CALLBACK_TYPE_SIGNATURE) {
            //签名回显
            var oInput = $('#qian-input');
            var oImg = $('#img');
            $('#qian-input').hide()
            $('#img').show().css('border','none')
            $('#img').attr('src','data:image/gif;base64,' + val)
            testGenData();//生成加密字符串
            confirmTest();//进行CA验证
        }
        else if (context_type == CALLBACK_TYPE_ON_PICTURE_TAKEN) {
            document.getElementById('preview').src = 'data:image/gif;base64,' + val;
        } else if (context_type == CALLBACK_TYPE_ON_MEDIA_DATA) {
            var audio = document.createElement('audio');
            if (audio != null && audio.canPlayType && audio.canPlayType("audio/mpeg")) {
                audio.src = "data:image/gif;base64," + val;
                audio.play();
            }
        }
        setAlertTitle();
    };//测试回调，将回调数据显示

    ////////////////////////////////////////////////
    apiInstance = new AnySignApi();

    //初始化签名接口
    res = apiInstance.initAnySignApi(callback, channel);

    if (!res) {
        alert("init error");
    } else {

    }
    ////////////////////////////////////////////////

    //注册单字签字对象20
    res = testAddSignatureObj(20);
    if (!res) {
        alert("testAddSignatureObj error");
    } else {

    }
    ////////////////////////////////////////////////

    //注册一个单位签章

    var cachet_config = new CachetConfig(new Signer("小明", "110xxxxxx"), new SignRule_Tid("1121_cachet"), true);

    res = apiInstance.addChachetObj(cachet_config);
    ////////////////////////////////////////////////

    if (!res) {
        alert("addChachetObj error");
    } else {

    }
    ////////////////////////////////////////////////

    //将配置提交
    res = apiInstance.commitConfig();

    if (res) {
        //alert("Init ALL 初始化成功");
    } else {
        //alert("Init ALL 初始化失败");
    }

    ////////////////////////////////////////////////

}


function testIsReadyToUpload() {
    alert("testIsReadyToUpload :" + apiInstance.isReadyToUpload());
}

//生成签名加密数据
function testGenData() {
    var res = document.getElementById('result');

    try {
        res.value = apiInstance.getUploadDataGram();
    }
    catch (err) {
        alert(err);
    }
}

//弹出签名框签名
function testPopupDialog(context_id) {
    switch (apiInstance.showSignatureDialog(context_id)) {
        case RESULT_OK:
            break;
        case EC_API_NOT_INITED:
            alert("信手书接口没有初始化");
            break;
        case EC_WRONG_CONTEXT_ID:
            alert("没有配置相应context_id的签字对象");
            break;
    }
}

//获取签名api版本信息
function testGetVersion() {
    alert(apiInstance.getVersion());
}

//获取设备操作系统信息
function testGetOsInfo() {
    alert(apiInstance.getOSInfo());
}
//提交
function confirmTest() {
    var strJSON = document.getElementById("result").value;
    //为了防止后台XSS过滤，暂时将加密字符串某些字符替换
    var strJSONStr = strJSON.replace(/"/g, "#");
    var dataUrl = $("#img").attr('src');
    var pSign = "";
    var pSign0 = "";
    $("#anysign_sign_01").find("p").each(function (i, e) {
        var str = e.innerHTML.replace(/\n/g, "");
        pSign0 = pSign0 + str + "&";
    });
    if (pSign0 != "") {
        pSign = pSign0 + "#";
    }
    var pSign1 = "";
    $("#anysign_sign_02").find("p").each(function (i, e) {
        var str = e.innerHTML.replace(/\n/g, "");
        pSign1 = pSign1 + str + "&";
    });
    if (pSign1 != "") {
        pSign = pSign + pSign1 + "#";
    }
    var pSign2 = "";
    $("#anysign_sign_03").find("p").each(function (i, e) {
        var str = e.innerHTML.replace(/\n/g, "");
        pSign2 = pSign2 + str + "&";
    });
    if (pSign1 != "") {
        pSign = pSign + pSign2 + "#";
    }
    // console.log({
    //     imageData: dataUrl,
    //     signData: strJSONStr,
    //     p: pSign,
    //     signKey: "13524242834"
    // })
    return {
        imageData: dataUrl,
        signData: strJSONStr,
        p: pSign,
        signKey: "13524242834"
    }
}

if (typeof define === 'function' && define.amd) {
    define([], function () {
        return {
            init: setAlertTitle,
            toJSON: confirmTest
        };
    });
}
