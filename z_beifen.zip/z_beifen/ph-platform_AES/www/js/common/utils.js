/*!
 * Utils utils子模块
 * @module utils
 * @author 周一平
 * @history 2015-6-10 add
 */
define(['underscore', 'libs/aes'], function(_, AES) {
    var Utils = {
        /**
         * 公共方法定义
         * @example: http://xxx.com/a.do?productCode=P001
         *     Result:  C.getParameter('productCode')  // 'P001'
         */
        getParameter : function (param) {
            var re = /&amp;/g,
                hrefStr = location.search;
            hrefStr = hrefStr.replace(re, "&");
            var reg = new RegExp('[&,?,&amp;]' + param + '=([^\\&]*)', 'i');
            hrefStr = decodeURIComponent(decodeURIComponent(hrefStr));
            var value = reg.exec(hrefStr);
            return value ? value[1] : '';
        },
        /**
         * 获取URL参数对象
         * @param queryString
         * @returns {{}}
         */
        getQueryMap: function (queryString) {
            var paramObj = {},
                paramList,
                oneQueryMatch,
                regGlobal = /[\?\&][^\?\&]+=[^\?\&#]+/g,
                regOne = /[\?\&]([^=\?]+)=([^\?\&#]+)/;

            queryString = queryString || location.href;
            paramList = queryString.match(regGlobal);

            if (!paramList) {
                return paramObj;
            }

            for (var i = 0, len = paramList.length; i < len; i++) {
                oneQueryMatch = paramList[i].match(regOne);
                if (null === oneQueryMatch) {
                    continue;
                }
                paramObj[oneQueryMatch[1]] = oneQueryMatch[2];
            }

            return paramObj;
        },
        //金额格式化
        formatMoney: function(s, n){
            if (isNaN(s) || String(s) == '' ? true : false) return s;
            n = n > 0 && n <= 20 ? n : 2;
            s = parseFloat((s + '').replace(/[^\d.-]/g, '')).toFixed(n) + '';
            var l = s.split('.')[0].split('').reverse(),
                r = s.split('.')[1];
            var t = '';
            for(var i = 0; i < l.length; i ++ )
            {
                t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? ',' : '');
            }
            return t.split('').reverse().join('') + '.' + r;
        },
        // 调用AES加密库
        AESDecrypt: function (word, type) {
            var result = word;
            if (window.CryptoJS) {
                var CryptoJS = window.CryptoJS;
                // 密钥
                var key = CryptoJS.enc.Utf8.parse('kTKQL2c6IkK4umXq');
                // 偏移量
                var iv = CryptoJS.enc.Utf8.parse('kTKQL2c6IkK4umXq');
                // 加密方法
                var Encrypt = function (word) {
                    var srcs = CryptoJS.enc.Utf8.parse(word);
                    var encrypted = CryptoJS.AES.encrypt(srcs, key, {
                        iv: iv,
                        mode: CryptoJS.mode.CBC,
                        padding: CryptoJS.pad.Pkcs7
                    });
                    return CryptoJS.enc.Base64.stringify(encrypted.ciphertext);
                };
                // 解密方法
                var Decrypt = function (word) {
                    word = word.replace('/\n/g', ''); // 去除加密串中的换行符
                    var decrypted = CryptoJS.AES.decrypt(word, key, {
                        iv: iv,
                        mode: CryptoJS.mode.CBC,
                        padding: CryptoJS.pad.Pkcs7
                    });
                    return decrypted.toString(CryptoJS.enc.Utf8);
                };
                if (type == 'Encrypt') {
                    result = Encrypt(word);
                } else if (type == 'Decrypt') {
                    result = Decrypt(word);
                }
            }
            return result;
        }
    };
    return Utils;
});
