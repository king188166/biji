define([], function() {
    var getParam = function(param){
        var reg = new RegExp('[&,?,&amp;]' + param + '=([^\\&]*)', 'i');
        var hrefStr = location.search;
        hrefStr = decodeURIComponent(decodeURIComponent(hrefStr));
        var value = reg.exec(hrefStr);
        return value ? value[1] : '';
    }
    if(getParam("ssEnv").toUpperCase()){
        sessionStorage.setItem('iLoan_ssEnv',getParam("ssEnv").toUpperCase());
    }
    if(getParam("pafEnv").toUpperCase()){
        sessionStorage.setItem('iLoan_pafEnv',getParam("pafEnv").toUpperCase());
    }
    var ssEnv = sessionStorage.getItem('iLoan_ssEnv'),
        pafEnv = sessionStorage.getItem('iLoan_pafEnv');
    var jsonData = {
            ssEnv : ssEnv || getParam("ssEnv").toUpperCase() || "PRODUCTION",
            pafEnv : pafEnv || getParam("pafEnv").toUpperCase() || "PRD"
    }
    /*var jsonData = {
        ssEnv : "STG3",
        pafEnv : "STG1",
        devEnv: "DEVELOPMENT"
    }*/
    return jsonData;
})
