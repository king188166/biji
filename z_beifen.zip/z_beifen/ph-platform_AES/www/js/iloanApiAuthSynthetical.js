/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 电子签名展示页
 */
define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    
    var Page = View.extend(_.extend({
        events: {
            'tap #js-back': 'back'
        },
        initialize: function() {
            var keys = C.Utils.getParameter('key');
            var data = {
                loanCompanyCode: JSON.Parse(C.Utils.AESDecrypt(keys)).loanCompanyCode
            };
            this.render(data);
        },
        render: function(data) {
            $('#js-auth-synthetical').html(_.template($('#js-auth-synthetical-L').html(), data));
        },
        back: function(e) {
            e = e || window.event;
            e.stopPropagation();
            window.location.href = 'iloan_api_esign.html?key='+C.Utils.getParameter('key');
        }
    }));
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});