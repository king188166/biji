/**
 * @author: ex-dushanshan@pingan.com.cn
 * @date  : 2017-8-29
 * @time  : 下午14:10
 * @describe: 电子签名展示页
 */
define(['zepto', 'C', 'view', 'js/dosign'], function ($, C, View, dosign) {
    'use strict';
    
    var Page = View.extend(_.extend({
        events: {
            'tap .qianming': 'esign',
            'tap #agree_btn': 'submitEsign'
        },
        initialize: function() {
            this.barCode = 'iloan' + Math.round(Math.random() * 1000) + new Date().getTime();
            this.config = {
                businessId: this.barCode,                   // 集成信手书业务的唯一标识
                template_serial: '1#4000',                  // 用于生成PDF的模板ID
                channel: '10010',                           // 渠道号，由信手书提供，请咨询项目经理
                sign_keyword: '授权人'                       // 签名关键词
            },
            this.paramsObj = this.getQueryParams();
            this.render(this.paramsObj);
        },
        getQueryParams: function() {
            var params = {
                // 上传电子签名接口所需入参
                accountId: C.Utils.getParameter('accountId') || '1234',
                OS: C.Utils.getParameter('OS') || 'A',
                token: C.Utils.getParameter('token') || 'b8361532fcbe41839139b597fb68a8b0',
                // 授权书的展示相关字段
                eType: C.Utils.getParameter('eType') || 'SQ',
                fundingModel: C.Utils.getParameter('fundingModel') ||'U',
                signElectSw: C.Utils.getParameter('signElectSw') || 'Y', // 电子签名开关
                cgiBankName: C.Utils.getParameter('cgiBankName') || '重庆银行',
                loanCompanyCode: C.Utils.getParameter('loanCompanyCode') || 'L',
                isCredit: C.Utils.getParameter('isCredit') || '1',

                ratio: C.Utils.getParameter('ratio') || '',
                // 银行变更接口所需字段
                newBank: C.Utils.getParameter('newBank') || '',
                bankCode: C.Utils.getParameter('bankcode') || '',
                applyNo: C.Utils.getParameter('applyNo') || '',
                payApplyNo: C.Utils.getParameter('payApplyNo') || '',
                // 成功失败的返回页面
                successLink: C.Utils.getParameter('successLink') || 'iloan_api_contract.html',
                failLink: C.Utils.getParameter('failLink') || 'iloan_api_data_transfer_contract.html'
            };
            // 银行变更场景时，不返回signElectSw字段
            if(params.eType === 'UP'){
                params.signElectSw = 'Y';
            }
            return params;
        },
        // 渲染电子签名页面
        render: function(data) {
            $('#esign_section').html(_.template($('#js-html-esign').html(), data));
            // 根据不同资金模式展示不同的授权书
            if (data.fundingModel && (data.fundingModel == 'U' || data.fundingModel == 'D')) {
                $('#zxsq_cgi').show();
                // 当是银行变更时，不会传loanCompanyCode
                data.loanCompanyCode = data.loanCompanyCode || '';
                switch (data.loanCompanyCode) {
                    case 'C':
                        $('.zxsq_cgi_c').show();
                        break;
                    case 'H':
                        $('.zxsq_cgi_h').show();
                        break;
                    default:
                        $('.zxsq_cgi_l').show();
                        break;
                }
            } else {
                if (data.loanCompanyCode == 'C') {
                    $('#zxsq_l').hide();
                    $('#zxsq_c').show();
                } else {
                    $('#zxsq_c').hide();
                    $('#zxsq_l').show();
                }
            }
            //银行变更时隐藏个人征信和综合授权书
            if(data.eType.toUpperCase() === 'UP') {
                $('.isShow').addClass('dn');
            }
            if (data.signElectSw === 'Y') {
                $('#esign_section').find('.signature').show();
                dosign.init(this.config);
            } else {
                $('#esign_section').find('.signature').hide();
            }
            // 综合授权页展示银行征信：U 并且需要征信；变更银行电子签名页必须征信，对应银行字段 newBank
            if (data.fundingModel && data.isCredit && data.fundingModel == 'U' && data.isCredit == '1' || !!data.newBank) {
                var bankClass = C.Constant.BANKCONTRACT[data.cgiBankName] || C.Constant.BANKCONTRACT[data.newBank];
                $('.'+bankClass).removeClass('dn');
            }
            $('#esign_section').show();
        },
        esign: function(){
            $('.container').addClass('dn');
            $('.signature-body').removeClass('dn');

        },
        
        // 提交电子签名信息
        submitEsign: function (e) {
            e = e || window.event;
            e.stopPropagation();
            // 判断是否已签名
            var isSigned = !$('#result')[0].value ? false : true;
            if (!isSigned && this.paramsObj.signElectSw === 'Y') {
                alert('请先签名');
                return;
            }
            alert('1111111111');
            var params = {};
            if (this.paramsObj.signElectSw === 'Y') {
                params.imgDenseStr = this.imgDenseStr;
                params.imgBytes = this.imgBytes;
            }
            params.loanCompanyCode = this.paramsObj.loanCompanyCode;
            params.platform = App.IS_IOS ? 'IOS' : 'A';
            params.businessNo = this.barCode;
            params.fundingModel = this.paramsObj.fundingModel;
            params.cgiBankName = this.paramsObj.cgiBankName;
            params.ratio = this.paramsObj.ratio; 
            params.productId = 'ILOANBT'; 
            // ocr参数可写成固定配置
            params.ocrKey = 'Y';
            params.ocrNeed = 'Y';
            params.isDomesticAlgorithm = 'Y';
            // 银行变更接口所需参数
            params.bankName = this.paramsObj.newBank;
            params.bankCode = this.paramsObj.bankCode;
            params.applyNo = this.paramsObj.applyNo;
            params.payApplyNo = this.paramsObj.payApplyNo;
            console.log(params);
            $('.shadding').show();
            var self = this;
            $.ajax({
                url: C.Api('UPLOADPOSELECTRONICSIGNATURE'),
                type: 'post',
                data: {
                    jsonPara: JSON.stringify(params)
                },
                success: function (res) {
                    if (res.flag == '1') {
                        console.log(self.paramsObj.successLink);
                        window.location.href = self.paramsObj.successLink;
                    } else { //OCR识别的结果校验，=3代表校验不通过需要重新签名;=2代表接口有问题
                        window.location.href = self.paramsObj.failLink;
                        // $('#img').hide().attr('src', '');
                        // $('#result').val('');
                        // $('#qian-input').show();
                    }
                },
                complete: function () {
                    $('.shadding').hide();
                }
            });
        },
        // 处理电子签名
        cancelCb: function(){
            $('.container').removeClass('dn');
        },
        successCb: function(){
            $('.container').removeClass('dn');
            this.imgBytes = dosign.toJSON().imageData;
            // 将signData的双引号替换成#号
            this.imgDenseStr = dosign.toJSON().signData;
        }
    }));
    $(function() {
        window.esignPage = new Page({
            el: $('body')[0]
        });
    });
});