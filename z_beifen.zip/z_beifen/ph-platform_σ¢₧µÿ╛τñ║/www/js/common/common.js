/*!
 * common模块提供zed_H5的所有基础功能以及环境初始化
 * @module common
 * @author 周一平
 * @history 2015-6-10 add
 */
define([
    "zepto",
    // 基础库 不依赖其他模块
    "js/common/env",
    "js/common/utils",
    "js/common/api",
    "js/common/flag",
    "js/common/constant",
    "js/common/init"
], function(
    $,
    EnvJson,
    Utils,
    Api,
    Flag,
    Constant,
    init
) {

    // 判断是否已经登录
    var C = {
        // 环境变量
        Env: EnvJson.ssEnv,
        // API
        Api: Api,
        // API
        Flag: Flag,
        // 常量
        Constant: Constant,
        // 工具类
        Utils: Utils,
        // 校验
        Validator: {}

    };
    init.apply(this);
    return C;
})
