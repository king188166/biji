/**
 * @author: ex-dushanshan001@pingan.com.cn
 * @date  : 2017-08-30
 * @describe: 合同签订(借款协议)
 */
define(['zepto', 'C', 'view'], function($, C, View) {
    'use strict';

    var Page = View.extend({
        initialize: function() {
            var paramsObj = C.Utils.getQueryMap();
            var params = {
                applyNo: paramsObj.applyNo,
                custName: decodeURIComponent(paramsObj.custName),
                id: paramsObj.id,
                credit: C.Utils.formatMoney(paramsObj.credit)
            };
            this.render(params);
        },
        // 初始页面渲染
        render: function(data) {
            data.Id = data.id.replace(/^(\d{4})\d{10}(.{4})$/, '$1**********$2');//渲染的时候用正则样式代替
            $('#js-wrap-applyNo').html(_.template($('#js-html-applyNo').html(), data));
            $('#js-wrap-contract').html(_.template($('#js-html-contract').html(), data));
        }
    });
    $(function() {
        new Page({
            el: $('body')[0]
        });
    });
});