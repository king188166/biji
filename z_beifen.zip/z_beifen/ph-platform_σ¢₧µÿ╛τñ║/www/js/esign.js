/**
 * @Author : linzequan958@pingan.com.cn
 * @Date   : 2016-03-30
 * @Time   : 17:12:49
 *
 * @Description: 电子签名组件
 */
define(['zepto', 'C', 'view', 'js/dosign'], function($, C, View, dosign) {

    'use strict';

    var Page = View.extend(_.extend({

        // 默认配置
        config: {
            businessId: '719314ea7b88304004c8ff498',    // 集成信手书业务的唯一标识
            template_serial: '1#4000',                  // 用于生成PDF的模板ID
            channel: '10010',                           // 渠道号，由信手书提供，请咨询项目经理
            sign_keyword: '授权人'                       // 签名关键词
        },

        // 初始化
        initialize: function() {
            var self = this;
            // 获取所有必要参数
            self.cb = C.Utils.getParameter('cb');
            self.token = C.Utils.getParameter('token');
            self.accountId = C.Utils.getParameter('accountId');
            console.log(self.cb);
            self.render();
        },

        // 渲染页面
        render: function() {
            dosign.init(this.config);
            $('#esign').trigger('click');
        },

        // 回跳页面前操作，返回成功
        successCb: function() {
            var result = {};
            result.imgData = dosign.toJSON().imageData;
            // 将signData的双引号替换成#号
            result.signData = dosign.toJSON().signData;
            result.signKey = '13524242834';

            // 将数据上报服务器，成功可以跳转回第三方

            var paramObject = {
                'canBack': false,
                'status': 'success'
            };
            if(this.cb.indexOf('?') != -1) {
                this.cb += ('&' + $.param(paramObject));
            } else {
                this.cb += ('?' + $.param(paramObject));
            }
            window.location.href = this.cb;
        },

        // 回调页面前操作，返回失败
        cancelCb: function() {
            var paramObject = {
                'canBack': false,
                'status': 'cancel'
            };
            if(this.cb.indexOf('?') != -1) {
                this.cb += ('&' + $.param(paramObject));
            } else {
                this.cb += ('?' + $.param(paramObject));
            }
            window.location.href = this.cb;
        }
    }));


    $(function() {
        window.esignPage = new Page({
            el: $('body')[0]
        });
    });
});
